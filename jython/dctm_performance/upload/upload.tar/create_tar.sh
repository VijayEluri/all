rm -f upload.tar
tar -cf upload.tar *.sh *.py *.properties *.dql
