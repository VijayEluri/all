export CLASSPATH=.:/dctm/shared/dfc/dfc.jar:$CLASSPATH
/opt/jython2.2.1/jython remove.py
