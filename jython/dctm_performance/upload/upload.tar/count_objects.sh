# /bin/bash
cp count.dql /tmp
su - dmadmin <<EOF1
idql DEMO -Udmadmin -Pdmadmin -R/tmp/count.dql
EOF1
