rm -rf files
mkdir files
python generate.py files
