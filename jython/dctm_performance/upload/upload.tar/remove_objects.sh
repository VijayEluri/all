# /bin/bash
cp ro.dql /tmp
su - dmadmin <<EOF1
idql DEMO -Udmadmin -Pdmadmin -R/tmp/ro.dql
EOF1
