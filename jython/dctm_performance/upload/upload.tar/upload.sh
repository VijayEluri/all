export CLASSPATH=.:/dctm/shared/dfc/dfc.jar:$CLASSPATH
rm -f nohup.out
rm -f *.log
nohup /opt/jython2.2.1/jython upload2.py &
